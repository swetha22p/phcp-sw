import React, { useEffect, useState } from "react";
import DriveInfoPopup from "./DriveInfoPopup/DriveInfoPopup";
import styles from "./DriveForms.module.scss";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllDrives, fetchAllForms, resetError, resetSuccess } from "../../../store/features/tools/driveSlice";
import CreateDrivePopup from "./CreateDrivePopup/CreateDrivePopup";
import CreateFormPopup from "./CreateFormPopup/CreateFormPopup";
import { showToast } from "../../../store/features/toast/toastSlice";

const DrivesForms = () => {
    const [ popupVisible, setPopupVisible] = useState(false);
    const [ createDrivePopup, setCreateDrivePopup ] = useState(false);
    const [ createFormPopup, setCreateFormPopup ] = useState(false);

    const success = useSelector(state => state.drive.success);
    const error = useSelector(state => state.drive.error);

    const driveData = {
        title: "Existing Drives",
        listItems: []
    };
    const [ formData, setFormData ] = useState({
        title: "Existing Forms",
        listItems: []
    });

    driveData.listItems = useSelector(state => state.drive.driveList);
    formData.listItems = useSelector(state => state.drive.formList);
    
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(fetchAllDrives());
        dispatch(fetchAllForms());
    }, [dispatch]);


    useEffect(()=>{
        if(success){
            dispatch(showToast({toastType: "success", toastMessage: success['success']}));
            dispatch(resetSuccess())
        }
        if(error){
            dispatch(showToast({toastType: "error", toastMessage: error['error']}));
            dispatch(resetError());
        }
    },[success, error, dispatch]);

    const handleCreate = (label) => {
        console.log("Create", label);
        switch (String(label).toLowerCase()) {
            case "drive":
                setCreateDrivePopup(true);
                break;
            case "form":
                setCreateFormPopup(true);
                break;
        
            default:
                console.log("Invalid label");
                break;
        }
    }

    const onCreateFormHandler = () => {
        console.log("here");
        setCreateDrivePopup(false);
        setCreateFormPopup(true);
    }
    

    const listTemplate = (data) => (
        <div className={styles.listSection}>
            <div className={styles.title}>{data.title}</div>
            <div className={styles.list}>
                {data.listItems.length===0 && <div style={{padding: '15px'}}>No record found</div>}
                {data.listItems.length>0 && data.listItems.map((item, idx) => (
                    <div className={styles.item} key={idx}>
                        <div className={styles.name}>{item.name??item.formName}</div>
                        <div className={styles.info}>
                            <div className={styles.createdDate}>Date Created: {item.createdDate}</div>
                            <img src="/assets/icons/common/info.svg" alt="info" onClick={()=>{setPopupVisible(true)}} />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    return (
        <>
            {/* <h1>DrivesForms</h1> */}
            {createDrivePopup && <CreateDrivePopup onCreateFormClick={onCreateFormHandler} onClose={()=>{setCreateDrivePopup(false); dispatch(fetchAllDrives())}} />}
            {createFormPopup && <CreateFormPopup onClose={()=>{setCreateFormPopup(false); dispatch(fetchAllForms())}} />}
            {popupVisible && <DriveInfoPopup onClose={()=>{setPopupVisible(false)}} />}
            <div className={styles.container}>
                <div className={styles.actionButtonGrp}>
                    {["drive", "form"].map((label, idx) => (
                        <div className={styles.actionBtn} key={idx} onClick={()=>{handleCreate(label)}}>
                            <i className="pi pi-plus"></i>
                            <img src="/assets/icons/common/createform.svg" alt="create form" />
                            <div className={styles.label}>CREATE {label.toUpperCase()}</div>
                        </div>
                    ))}
                </div>
                <div className={styles.searchBar}>
                    <input type="text" />
                    <div className={styles.searchIcon}>
                        <i className="pi pi-search"></i>
                    </div>
                </div>
                <div className={styles.table}>
                    {driveData && listTemplate(driveData)}
                    {listTemplate(formData)}
                </div>
            </div>
        </>
    );
}

export default DrivesForms;