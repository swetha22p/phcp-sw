import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

const indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB || window.shimIndexedDB;
const request = indexedDB.open("ResponseDatabase", 1);

request.onerror = function(event) {
  console.error("An error occured with IndexedDB");
  console.error(event);
};

request.onupgradeneeded = function() {
  const db = request.result;
  const store = db.createObjectStore("responses", {keyPath: "name"});
  store.createIndex("Email", ["email"], {unique : false});
  store.createIndex("Messgae", ["message"], {unique : false});
};

function App() {
  const [data, setData] = useState([]);
  const [mode, setMode] = useState('online');
  const [show, setShow] = useState(false);
  const responsesqueue = [];

  useEffect(() => {
    let url = "https://jsonplaceholder.typicode.com/users"
    fetch(url).then((response) => {
      response.json().then((result) => {
        console.warn(result)
        setData(result)
        localStorage.setItem("users", JSON.stringify(result))
      })
    }).catch(err => {
      let collection=localStorage.getItem('users');
      setData(JSON.parse(collection))
    })
  }, [show]);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://10.8.0.13:5000/upload', {
       method: 'POST',
       body: JSON.stringify({
        "name" : e.target.name.value,
        "email" : e.target.email.value,
        "message" : e.target.message.value
       }),
       headers: {
          'Content-type': 'application/json; charset=UTF-8',
       },
    }).then((res) => res.json())
       .catch((err) => {
          console.log(err.message);
          const db = request.result;
          const transaction = db.transaction("responses", 'readwrite');

          const store = transaction.objectStore("responses");
          store.put({name: e.target.name.value, email: e.target.email.value, message: e.target.message.value});
          return transaction.complete;
       });
    };

    const videoUrls = async () => {
      while(responsesqueue.length){
        try{
          const response = await fetch('http://10.8.0.13:5000/upload', {
          method: 'POST',
          body: responsesqueue[0],
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
          },
          })
          const json = await response.json()
          responsesqueue.shift();
          console.log(json);
        }
          catch(e) {
            console.log("Wait for Internet Connection");
            break;
          }
        }
     }

    const SubmitAll = (e) => {
      e.preventDefault();
      const db = request.result;
      const transaction = db.transaction("responses", 'readwrite');
      const store = transaction.objectStore("responses");
      store.openCursor().onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          responsesqueue.push(JSON.stringify({
              "name" : cursor.value.name,
              "email" : cursor.value.email,
              "message" : cursor.value.message
              }));
          cursor.delete();
          cursor.continue();
        } else {
          console.log(`Got all customers: ${responsesqueue}`);
          videoUrls();
        }
      }
  };      

  return (
    <>
    <form id="myForm" onSubmit={handleSubmit}>
      <div className="form-control">
          <label htmlFor="name">Name</label>
          <input type="text" name="name" placeholder="Enter your name" />
      </div>

      <div className="form-control">
          <label htmlFor="email">Email</label>
          <input type="text" name="email" placeholder="Enter your email" />
      </div>

      <div className="form-control">
          <label htmlFor="message">Message</label>
          <textarea name="message" cols="30" rows="10" placeholder="Enter your message"></textarea>
      </div>
      <input type="submit" value="Submit" className="submit-btn" />
    </form>
    <div>
      <button type="button" onClick={SubmitAll}>Submit All</button>
    </div>
    <div>
      <button type="button_1" onClick={()=>setShow(true)}>Show Table</button>
    </div>
    {show === true && 
    <table>
                <thead>
                    <tr>
                        <th rowSpan="2">ID</th>
                        <th rowSpan="2">Name</th>
                        <th rowSpan="2">Username</th>
                        <th rowSpan="2">Email</th>
                        <th>Address</th>
                        <th>Street</th>
                        <th>Suite</th>
                        <th>City</th>
                        <th>Zipcode</th>
                        <th>Geo</th>
                        <th rowSpan="2">Phone</th>
                        <th rowSpan="2">Website</th>
                        <th>Company</th>
                        <th>Name</th>
                        <th>CatchPhrase</th>
                        <th>BS</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((item, idx) => (
                        <tr key={idx}>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.username}</td>
                            <td>{item.email}</td>
                            <td>{item.address.street}</td>
                            <td>{item.address.suite}</td>
                            <td>{item.address.city}</td>
                            <td>{item.address.zipcode}</td>
                            <td>{item.address.geo.lat} {item.address.geo.lng}</td>
                            <td>{item.phone}</td>
                            <td>{item.website}</td>
                            <td>{item.company.name}</td>
                            <td>{item.company.catchPhrase}</td>
                            <td>{item.company.bs}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        } 
    </>
  );
}

export default App;
