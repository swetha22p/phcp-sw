from flask import Flask, render_template, request, jsonify
from flask_cors import CORS, cross_origin

app = Flask(__name__)
CORS(app)

@app.route('/upload', methods=["POST"])
@cross_origin()
def upload():
    if request.method == "POST":
        data = request.get_json()
        name = data["name"]
        email = data["email"]
        message = data["message"]
        data = {
            "name" : name,
            "email" : email,
            "message" : message
        }
        print(data)
        return jsonify({200 : data})
   

if __name__ == '__main__':
   app.run(host="0.0.0.0", debug = True)