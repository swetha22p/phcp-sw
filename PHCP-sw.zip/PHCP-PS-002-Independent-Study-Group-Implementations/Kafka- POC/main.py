from flask import Flask, request, jsonify
import requests
from internal import internal_call
from external_api import external_api_call
# from get_json import get_data
import datetime

app = Flask(__name__)

KAFKA_SERVER_ADDR = "10.8.0.13:9092"
# change the "DB_INSERTION_API_URL"
DB_INSERTION_API_URL = "http://localhost:8000/reg"


@app.route('/dlf', methods = ['POST'])
def dlf():
    data = request.get_json()
    decision = "NO"

    # INTERNAL API CALL
    if data["external_api_call"] == False:
        decision = internal_call(data)

    # EXTERNAL API CALL
    else:
        decision = external_api_call(data)

    result = {
        "id": data["id"],
        "decision": decision
    }
    return result

@app.route('/reg', methods = ['POST'])
def reg():
    data = request.get_json()
    api_name = data["api_name"]
    input_format = data["format"]

    uid = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
    producer = api_name + "_" + uid + "_" + "producer"
    consumer = api_name + "_" + uid + "_" + "consumer"
    
    # call db api to store the data
    data["kafka_addr"] = KAFKA_SERVER_ADDR
    data["producer"] = producer
    data["consumer"] = consumer
    r = requests.post(url = DB_INSERTION_API_URL, data = data)

    return_obj = {}
    return_obj["kafka_addr"] = KAFKA_SERVER_ADDR
    return_obj["consumer"] = producer
    return_obj["producer"] = consumer

    return return_obj

if __name__ == '__main__':
	app.run(host = "0.0.0.0" , port=8000, debug=True)