import os
import sys

def get_input_data():
    # expose an api to receive input data
    # hardcode for now
    in_data = [
        {
            "test": "malaria",
            "subfield": "weight",
            "datatype": "int",
            "value": 80,
        },
        {
            "test": "typhoid",
            "subfield": "glucose",
            "datatype": "int",
            "value": 74
        }
    ]
    return in_data

def get_contract():
    # call an exposed api to get the contract
    # json can be restrucutured
    # hardcode for now
    contract = {
        "multiple_conditions":"True",
        "condition":"AND",
        "number_of_tests": "2",
        "tests": ["malaria", "typhoid"],
        "malaria": {
            "subfield": "weight",
            "datatype": "int",
            "limits": [
                {
                    # key: condition, value = list[operator, value, decision]
                    "operator":"gte",
                    "value": 50,
                },
                {
                    "operator":"lt",
                    "value": 100,
                }
            ]
        },
        "typhoid": {
            "subfield": "glucose",
            "datatype": "int",
            "limits": [
                {
                    "operator":"eq",
                    "value": 74,
                },
            ]
        }

        # gt = greater than
        # lt = less than
        # gte = greater than or equal to
        # lte = less than or equal to
        # eq = equal to
        # neq = not equal to
    }
    return contract


def output_decision(decision):
    # do something based on the decision
    print("Decision: ", decision)

def make_decision(input_data, contract):
    # make a decision based on the input data and contract
    number_of_tests = int(contract["number_of_tests"])

    # error checking
    for i in range(number_of_tests):
        if(input_data[i]["test"] not in contract["tests"]):
            print("Some or ALL test contract not available")
            return "INVALID INPUT"
        if input_data[i]["subfield"] != contract[input_data[i]["test"]]["subfield"]:
            print("Some or ALL subfield contract not available")
            return "INVALID INPUT"
        if input_data[i]["datatype"] != contract[input_data[i]["test"]]["datatype"]:
            print("Some or ALL datatype not matching")
            return "INVALID INPUT"

    final_decision = []
    test_condition = contract["condition"]
    for i in range(number_of_tests):
        test_name = input_data[i]["test"]
        test = contract[test_name]

        result_disease = []
        for j in range(len(test["limits"])):
            operator = test["limits"][j]["operator"]
            value = test["limits"][j]["value"]
            if operator == "gt":
                if input_data[i]["value"] > value:
                    result_disease.append(True)
                else:
                    result_disease.append(False)
            elif operator == "lt":
                if input_data[i]["value"] < value:
                    result_disease.append(True)
                else:
                    result_disease.append(False)
            elif operator == "gte":
                if input_data[i]["value"] >= value:
                    result_disease.append(True)
                else:
                    result_disease.append(False)
            elif operator == "lte":
                if input_data[i]["value"] <= value:
                    result_disease.append(True)
                else:
                    result_disease.append(False)
            elif operator == "eq":
                if input_data[i]["value"] == value:
                    result_disease.append(True)
                else:
                    result_disease.append(False)
            elif operator == "neq":
                if input_data[i]["value"] != value:
                    result_disease.append(True)
                else:
                    result_disease.append(False)
        # AND the result for range values
        # simply multiple tests for a single disease
        if False in result_disease:
            final_decision.append(False)
        else:
            final_decision.append(True)

    # checking the condition sent in contract for multiple diseases    
    if test_condition == "AND":
        if False in final_decision:
            return False
        else:
            return True
    elif test_condition == "OR":
        if True in final_decision:
            return True
        else:
            return False
    

def main():
    input_data = get_input_data()
    contract = get_contract()
    decision = make_decision(input_data, contract)
    output_decision(decision)


if __name__ ==  "__main__":
    main()