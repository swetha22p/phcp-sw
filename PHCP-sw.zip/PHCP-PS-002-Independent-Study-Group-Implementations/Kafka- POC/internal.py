def internal_call(data):
    ip = data["input"]
    operation = data["operation"]
    logic = data["logic"]
    
    input_data = {}

    if operation == "AND":
        default_decision = True
    elif operation == "OR":
        default_decision = False
    
    decision = default_decision

    for row in ip:
        subfield = row[1]
        value = row[2]
        input_data[subfield] = value

    for row in logic:
        subfield = row[0]
        condition = row[1]
        value = row[2]

        decision_row = default_decision

        if condition == "eq":
            decision_row = input_data[subfield] == value
        elif condition == "neq":
            decision_row = input_data[subfield] != value
        elif condition == "gt":
            decision_row = input_data[subfield] > value
        elif condition == "gte":
            decision_row = input_data[subfield] >= value
        elif condition == "lt":
            decision_row = input_data[subfield] < value
        elif condition == "lte":
            decision_row = input_data[subfield] <= value
        
        if operation == "AND":
            decision = decision and decision_row
        elif operation == "OR":
            decision = decision or decision_row

    if decision is True:
        result = "Yes"
    else:
        result = "NO"       
    return result