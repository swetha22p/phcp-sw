import json
from kafka import KafkaProducer, KafkaConsumer

def read_from_topic(topic, KAFKA_SERVER_ADDR):
    try:
        # print(topic)
        consumer = KafkaConsumer(
            topic,
            bootstrap_servers = [KAFKA_SERVER_ADDR],
            enable_auto_commit = True,
            consumer_timeout_ms = 5000
        )
        print("consumer made")
        msg_list = list()
        for msg in consumer:
            print(msg)
            msg_list.append(json.loads(msg.value))
            break
        print("message consumed")
        print(msg_list)
        consumer.close()
        return msg_list

    except Exception as e:
        print("============Something went wrong=============", e)
        return []

def post_to_producer(topic_name, msg, KAFKA_SERVER_ADDR):
    try:
        producer = KafkaProducer(
            bootstrap_servers = [KAFKA_SERVER_ADDR],
            value_serializer = lambda msg: json.dumps(msg).encode('utf-8')
        )
        producer.send(topic=topic_name, value=msg)
        # print("Producer : ", msg)
        return True
    except Exception as e:
        print("============Something went wrong=============", e)
        return False

def external_api_call(data):
    P_topic = data["external_api_details"]["producer"]
    C_topic = data["external_api_details"]["consumer"]
    KAFKA_SERVER_ADDR = data["external_api_details"]["kafka_addr"]
    input_format = data["external_api_details"]["format"]

    # default decision
    decision = "UNKNOWN"

    # create dictionary on input data
    ip = data["input"]
    input_data = {}
    for row in ip:
        subfield = row[1]
        value = row[2]
        input_data[subfield] = value

    # structure the data in the format required by the external api
    data_to_produce = []
    for row in input_format:
        subfield = row[0]
        datatype = row[1]
        value = input_data[subfield]
        data_to_produce.append([subfield, datatype, value])

    # produce the data
    post_to_producer(P_topic, data_to_produce, KAFKA_SERVER_ADDR)
    
    # consume the data
    decision = read_from_topic(C_topic, KAFKA_SERVER_ADDR)
    
    if decision == []:
        decision = "UNKNOWN"

    return {"decision", decision}


